CSV IMPORT STARTER KIT — FREE LOCAL EDITION 1.0

START
Extract the ZIP and open start-here.html in a modern desktop browser.
No installation, account, internet connection or paid API is required to
use the downloaded checker. Store links need an internet connection.

Use Load an imperfect example, or choose a UTF-8 CSV/TSV. Pick the matching
profile. Header names are exact and case-sensitive. Use Basic structure
for a file with a different schema; it does not check custom field rules.

FREE CHECKER LIMITS
200 data records, 50 header columns, 512 KiB. A file over a limit is rejected,
not silently truncated. No cells are changed and there is no cleaned CSV
export. JSON findings can be saved locally. Fixed profiles only; custom
rules and folder processing are available in the full RowReady edition.
The browser table shows 50 findings; stored reports cap at 10,000 findings.
Email checks validate basic syntax, not deliverability. Dates use YYYY-MM-DD.
Decimal numbers are ungrouped. A clean report is not import certification.

EXAMPLES
All records are synthetic. Email addresses use the reserved .invalid domain
and do not deliver mail. Use the matching profile for expected counts:
  contacts-needs-review.csv: 5 findings; contacts-clean.csv: 0
  inventory-needs-review.csv: 4 findings; inventory-clean.csv: 0
  orders-needs-review.csv: 4 findings; orders-clean.csv: 0

REUSABLE RULES
The policies folder contains JSON presets for the full RowReady edition.
The free checker has these rules built in. These are generic practice
schemas, not official Shopify, Salesforce, accounting or regulatory formats.
Adapt them to your destination's actual schema before using them in a job.

HANDOFF CHECKLIST
1. Keep the untouched source and identify the system of record.
2. Confirm target headers, required values, unique keys and allowed values.
3. Confirm date/decimal formats, units, currency and encoding.
4. Preserve leading zeros and long identifiers as text.
5. Review duplicates, empty values, widths and formula-like values.
6. Resolve ambiguous values from source evidence; do not invent data.
7. Rehearse in a test workspace or destination preview with a small subset.
8. Reconcile source, accepted, rejected and skipped record counts.
9. Spot-check imported values and retain an error report and rollback plan.

PRIVACY
Processing is local. No analytics, data uploads, external scripts or browser
storage are used by the checker. The checklist is temporary and not saved.
Reports contain filenames, column names and findings; keep them private
when these identify a customer or project. Clearing the page resets its
working data; downloaded reports remain wherever you saved them.
Do not upload customer data to unrelated services to troubleshoot an import.

FULL TOOLS
RowReady: https://genosyde.gumroad.com/l/rowready
NameHarbor (Windows x64 only): https://genosyde.gumroad.com/l/nameharbor
This kit does not include the paid applications. Check current prices,
platform requirements and license terms on their store pages before buying.

Full two-tool bundle: https://genosyde.gumroad.com/l/offline-desk-toolkit
USD 22 base price as of November 5, 2026; USD 28 separately. Check checkout
for current price, local currency and tax. Includes a Windows-only app.
